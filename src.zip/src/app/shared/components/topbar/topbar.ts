import {
  Component,
  inject,
  OnInit,
  signal,
  effect,
  ViewChild,
  ElementRef,
  HostListener,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { UiService } from '../../services/ui.service';
import { NotesService } from '../../../core/services/notes.service';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-topbar',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './topbar.html',
})
export class TopbarComponent implements OnInit {
  ui = inject(UiService);
  notesService = inject(NotesService);
  authService = inject(AuthService);
  isDarkMode = signal(false);

  isUserMenuOpen = signal(false);
  isLanguageMenuOpen = signal(false);

  @ViewChild('titleInput') private titleInput!: ElementRef<HTMLInputElement>;
  private currentNoteId: string | null = null;
  private lastKnownTitle = '';

  // Atajo de teclado para abrir el modal de búsqueda (All Notes)  @HostListener('window:keydown.control.k', ['$event'])
  openSearch(event: any) {
    event.preventDefault();
    this.ui.isSearchModalOpen.set(true);
  }

  constructor() {
    effect(() => {
      const note = this.notesService.selectedNote();
      const newTitle = note?.titulo || '';
      const differentNote = note?.id !== this.currentNoteId;
      const titleChanged = newTitle !== this.lastKnownTitle;

      if (differentNote) {
        this.currentNoteId = note?.id || null;
        this.lastKnownTitle = newTitle;
        if (this.titleInput?.nativeElement) {
          this.titleInput.nativeElement.value = newTitle;
        }
      } else if (titleChanged) {
        this.lastKnownTitle = newTitle;
        if (document.activeElement !== this.titleInput?.nativeElement) {
          if (this.titleInput?.nativeElement) {
            this.titleInput.nativeElement.value = newTitle;
          }
        }
      }
    });
  }

  ngOnInit() {
    const theme = localStorage.getItem('theme');
    if (theme === 'dark' || (!theme && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
      this.isDarkMode.set(true);
      document.documentElement.classList.add('dark');
    }
  }

  toggleTheme() {
    this.isDarkMode.update((v) => !v);
    if (this.isDarkMode()) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }

  updateTitle() {
    const note = this.notesService.selectedNote();
    if (!note?.id) return;
    const newTitle = (this.titleInput.nativeElement.value || '').trim() || 'New Note';
    this.titleInput.nativeElement.value = newTitle;
    if (newTitle === note.titulo) return;

    this.ui.isSaving.set(true);
    this.ui.lastSaved.set(false);

    this.notesService
      .updateNote(note.id, {
        titulo: newTitle,
        contenido: note.contenido,
        pinned: note.pinned ?? false,
        archived: note.archived ?? false,
        fechaCreacion: note.fechaCreacion,
        fechaActualizacion: '',
      })
      .subscribe({
        next: (updated) => {
          this.notesService.selectNote(updated);
          this.notesService.triggerReload();
        },
      });
  }

  setSearchQuery(event: Event) {
    const input = event.target as HTMLInputElement;
    this.notesService.setSearchQuery(input.value);
  }

  toggleUserMenu() {
    this.isUserMenuOpen.update((v) => !v);
    if (!this.isUserMenuOpen()) {
      this.isLanguageMenuOpen.set(false);
    }
  }

  openLogin(): void {
    this.ui.isLoginOpen.set(true);
    this.isUserMenuOpen.set(false);
  }

  signOut(): void {
    this.authService.signOut();
    this.isUserMenuOpen.set(false);
  }
}
