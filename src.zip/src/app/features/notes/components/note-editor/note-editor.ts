// Importaciones necesarias de Angular y librerías externas
import { Component, signal, inject, effect, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { QuillModule, ContentChange } from 'ngx-quill'; // Editor Quill
import Quill from 'quill';
import { StyleAttributor, Scope } from 'parchment'; // Para registrar estilos personalizados
import Swal from 'sweetalert2'; // Alertas bonitas
import { NotesService } from '../../../../core/services/notes.service';
import { UiService } from '../../../../shared/services/ui.service';

// ==================================================
// REGISTRO DE ESTILOS PERSONALIZADOS EN QUILL
// Permite aplicar tamaños y fuentes arbitrarias (en px o font-family)
// ==================================================
const SizeStyle = new StyleAttributor('size', 'font-size', { scope: Scope.INLINE });
const FontStyle = new StyleAttributor('font', 'font-family', { scope: Scope.INLINE });
Quill.register(SizeStyle, true);
Quill.register(FontStyle, true);

// ==================================================
// BLOQUES PERSONALIZADOS: HR (línea horizontal) y Page Break (salto de página)
// ==================================================
const BlockEmbed = Quill.import('blots/block/embed') as any;

class HorizontalRule extends BlockEmbed {
  static blotName = 'hr';
  static tagName = 'HR';
}
Quill.register(HorizontalRule);

class PageBreak extends BlockEmbed {
  static blotName = 'page-break';
  static tagName = 'DIV';
  static className = 'ql-page-break';
  static create() {
    const node = super.create();
    node.setAttribute('contenteditable', 'false'); // Evita que se pueda editar el salto
    return node;
  }
}
Quill.register(PageBreak);

// ==================================================
// COMPONENTE: NoteEditorComponent
// Maneja el editor de notas (Quill), auto-guardado, importación de .docx,
// copiado con formato, descarga y limpieza del contenido.
// ==================================================
@Component({
  selector: 'app-note-editor',
  standalone: true,
  imports: [CommonModule, QuillModule],
  templateUrl: './note-editor.html',
  styleUrls: ['./note-editor.scss'],
})
export class NoteEditorComponent {
  // Inyección de servicios
  private notesService = inject(NotesService);
  private ui = inject(UiService);

  // Configuración de módulos de Quill (toolbar deshabilitada, historial activado)
  editorModules = {
    toolbar: false, // La barra de herramientas está en otro componente
    history: { delay: 1000, maxStack: 100, userOnly: true },
  };

  // Señales reactivas para la UI
  hasText = signal(false); // ¿Hay texto en el editor?
  wordCount = signal(0); // Número de palabras
  charCount = signal(0); // Número de caracteres
  copyDone = signal(false); // Feedback visual de copiado

  // Variables privadas
  private quillInstance: any = null; // Instancia del editor Quill
  private currentNoteId: string | null = null; // ID de la nota actual
  private saveTimeout: any = null; // Timeout para auto-guardado

  constructor() {
    // effect: se ejecuta cuando cambia la nota seleccionada
    effect(() => {
      const note = this.notesService.selectedNote();
      // Solo actualizar el editor si cambió la nota (evita recarga innecesaria)
      if (note && this.quillInstance && note.id !== this.currentNoteId) {
        this.currentNoteId = note.id || null;
        this.quillInstance.clipboard.dangerouslyPasteHTML(note.contenido || '');
        this.quillInstance.blur(); // Quita el foco al cargar una nota nueva
      }
      // Actualiza contadores sin importar si cambió la nota
      if (this.quillInstance) {
        const text = this.quillInstance.getText().trim();
        this.hasText.set(text.length > 0);
        this.charCount.set(text.length);
        this.wordCount.set(text.length > 0 ? text.split(/\s+/).length : 0);
      }
    });
  }

  // Se ejecuta cuando Quill ha sido creado (evento onEditorCreated)
  onEditorCreated(quill: any) {
    this.quillInstance = quill;
    this.notesService.setQuillInstance(quill); // Comparte la instancia con otros componentes
    const note = this.notesService.selectedNote();
    if (note) {
      this.currentNoteId = note.id || null;
      quill.clipboard.dangerouslyPasteHTML(note.contenido || '');
      quill.blur();
    }
  }

  // Se ejecuta en cada cambio de contenido del editor
  onEditorChanged(event: ContentChange) {
    const text = event.text.trim();
    this.hasText.set(text.length > 0);
    this.charCount.set(text.length);
    this.wordCount.set(text.length > 0 ? text.split(/\s+/).length : 0);

    // Reinicia el timeout de auto-guardado
    clearTimeout(this.saveTimeout);
    this.saveTimeout = setTimeout(() => {
      const note = this.notesService.selectedNote();
      if (!note?.id) return;

      const contenido = this.quillInstance?.root.innerHTML || '';

      // Auto-título: si el título es "Untitled Document", tomar la primera línea del contenido
      let titulo = note.titulo;
      if (titulo === 'Untitled Document' && text.length > 0) {
        const firstLine = text.split('\n')[0].trim();
        if (firstLine) titulo = firstLine.length > 60 ? firstLine.substring(0, 60) : firstLine;
      }

      // Activa indicadores de guardado en UI Service
      this.ui.isSaving.set(true);
      this.ui.lastSaved.set(false);

      // Actualiza la nota en Firebase (a través de NotesService)
      this.notesService
        .updateNote(note.id, {
          titulo,
          contenido,
          pinned: note.pinned ?? false,
          archived: note.archived ?? false,
          deleted: note.deleted ?? false,
          fechaCreacion: note.fechaCreacion,
          fechaActualizacion: '',
        })
        .subscribe({
          next: (updated) => {
            this.notesService.selectNote(updated);
            this.ui.isSaving.set(false);
            this.ui.lastSaved.set(true);
            // Si el título cambió, refresca la lista del sidebar
            if (titulo !== note.titulo) this.notesService.triggerReload();
          },
          error: (err) => {
            console.error('Error al guardar:', err);
            this.ui.isSaving.set(false);
          },
        });
    }, 1500); // Espera 1.5 segundos después de dejar de escribir
  }

  // ==================================================
  // Importar documento Word (.docx) usando Mammoth.js
  // ==================================================
  uploadDoc() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document';
    input.onchange = async () => {
      const file = input.files?.[0];
      if (!file) return;

      const doImport = async () => {
        try {
          const arrayBuffer = await file.arrayBuffer();
          const mammoth = (window as any).mammoth;
          if (!mammoth) {
            Swal.fire({
              title: 'Error',
              text: 'mammoth.js no está disponible.',
              icon: 'error',
              confirmButtonColor: '#18639c',
              width: '360px',
            });
            return;
          }
          const result = await mammoth.convertToHtml({ arrayBuffer });
          const html = result.value;
          if (!html?.trim()) return;

          // Inserta el HTML al final del editor
          const pos = this.quillInstance?.getLength() ?? 0;
          this.quillInstance?.clipboard.dangerouslyPasteHTML(pos > 1 ? pos - 1 : 0, html);

          // Guarda automáticamente después de importar
          const note = this.notesService.selectedNote();
          if (note?.id) {
            const contenido = this.quillInstance?.root.innerHTML || '';
            this.notesService
              .updateNote(note.id, {
                titulo: note.titulo,
                contenido,
                pinned: note.pinned ?? false,
                archived: note.archived ?? false,
                deleted: note.deleted ?? false,
                fechaCreacion: note.fechaCreacion,
                fechaActualizacion: '',
              })
              .subscribe({ next: (updated) => this.notesService.selectNote(updated) });
          }
        } catch {
          Swal.fire({
            title: 'Error',
            text: 'No se pudo leer el archivo.',
            icon: 'error',
            confirmButtonColor: '#18639c',
            width: '360px',
          });
        }
      };

      // Si ya hay contenido, pregunta antes de importar
      const hasContent = this.hasText();
      if (hasContent) {
        const { isConfirmed } = await Swal.fire({
          title: '<span class="text-[16px] font-bold">Import Document</span>',
          html: '<span class="text-[14px] text-gray-500">This will append the document content to the current note. Continue?</span>',
          showCancelButton: true,
          confirmButtonColor: '#18639c',
          cancelButtonColor: '#f3f4f6',
          confirmButtonText: 'Import',
          cancelButtonText: '<span class="text-gray-700">Cancel</span>',
          width: '420px',
          customClass: {
            popup: 'rounded-xl shadow-lg border border-gray-100',
            confirmButton: 'px-5 py-2 rounded-md font-medium text-white',
            cancelButton: 'px-5 py-2 rounded-md font-medium text-gray-700',
          },
        });
        if (!isConfirmed) return;
      }
      await doImport();
    };
    input.click();
  }

  // ==================================================
  // Copiar contenido al portapapeles con formato HTML y texto plano
  // ==================================================
  copyContent() {
    const html = this.quillInstance?.root.innerHTML || '';
    const text = this.quillInstance?.getText() || '';

    const blobHtml = new Blob([html], { type: 'text/html' });
    const blobText = new Blob([text], { type: 'text/plain' });
    const data = [new ClipboardItem({ 'text/html': blobHtml, 'text/plain': blobText })];

    navigator.clipboard
      .write(data)
      .then(() => {
        this.copyDone.set(true);
        setTimeout(() => this.copyDone.set(false), 2000);
      })
      .catch((err) => {
        console.error('Failed to copy: ', err);
      });
  }

  // ==================================================
  // Descargar la nota actual (TXT, PDF o WORD)
  // Solo TXT está implementado; los otros muestran "coming soon"
  // ==================================================
  downloadNote() {
    const note = this.notesService.selectedNote();
    const text = this.quillInstance?.getText() || '';
    let selectedFormat = 'txt';

    // Modal personalizado con SweetAlert2 para elegir formato
    Swal.fire({
      title: '<div class="text-left text-[18px] font-bold">Download Your Notes</div>',
      html: `
        <p class="text-[13px] text-gray-500 mb-4 text-left">Please Select the File Type of download your notes</p>
        <div class="flex justify-between gap-3">
          <div id="sel-txt" class="flex-1 cursor-pointer flex flex-col items-center justify-center p-4 border-2 border-blue-500 rounded-lg relative transition-all">
            <div id="dot-txt" class="w-3 h-3 bg-blue-500 rounded-full absolute top-2 right-2"></div>
            <span class="material-icons text-blue-500 text-[32px] mb-2">description</span>
            <span class="font-bold text-[13px] text-gray-800">TEXT</span>
          </div>
          <div id="sel-pdf" class="flex-1 cursor-pointer flex flex-col items-center justify-center p-4 border border-gray-200 rounded-lg relative hover:bg-gray-50 transition-all">
            <div id="dot-pdf" class="w-3 h-3 bg-gray-300 rounded-full absolute top-2 right-2 hidden"></div>
            <span class="material-icons text-red-500 text-[32px] mb-2">picture_as_pdf</span>
            <span class="font-bold text-[13px] text-gray-800">PDF</span>
          </div>
          <div id="sel-word" class="flex-1 cursor-pointer flex flex-col items-center justify-center p-4 border border-gray-200 rounded-lg relative hover:bg-gray-50 transition-all">
            <div id="dot-word" class="w-3 h-3 bg-gray-300 rounded-full absolute top-2 right-2 hidden"></div>
            <span class="material-icons text-blue-700 text-[32px] mb-2">article</span>
            <span class="font-bold text-[13px] text-gray-800">WORD</span>
          </div>
        </div>
      `,
      showConfirmButton: true,
      showCancelButton: true,
      showCloseButton: true,
      cancelButtonText: 'Dismiss',
      confirmButtonText:
        'Download <span class="material-icons text-[18px] align-middle ml-1">download</span>',
      confirmButtonColor: '#000000',
      cancelButtonColor: 'transparent',
      width: '450px',
      customClass: {
        cancelButton: 'text-gray-400 font-medium shadow-none hover:text-gray-600 transition-colors',
        confirmButton: 'px-5 py-2.5 rounded-lg font-medium text-white flex items-center',
        actions: 'justify-between w-full mt-6 px-1',
        popup: 'rounded-xl shadow-lg border border-gray-100 p-6',
      },
      didOpen: () => {
        // Configura los eventos de click en los cuadros de formato
        const els = ['txt', 'pdf', 'word'];
        els.forEach((id) => {
          document.getElementById(`sel-${id}`)?.addEventListener('click', () => {
            selectedFormat = id;
            els.forEach((otherId) => {
              const el = document.getElementById(`sel-${otherId}`);
              const dot = document.getElementById(`dot-${otherId}`);
              if (otherId === id) {
                el?.classList.replace('border-gray-200', 'border-blue-500');
                el?.classList.add('border-2');
                dot?.classList.remove('hidden');
                dot?.classList.replace('bg-gray-300', 'bg-blue-500');
              } else {
                el?.classList.replace('border-blue-500', 'border-gray-200');
                el?.classList.remove('border-2');
                dot?.classList.add('hidden');
                dot?.classList.replace('bg-blue-500', 'bg-gray-300');
              }
            });
          });
        });
      },
    }).then((result) => {
      if (result.isConfirmed) {
        const fileName = `${note?.titulo || 'nota'}`;
        if (selectedFormat === 'txt') {
          const blob = new Blob([text], { type: 'text/plain' });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `${fileName}.txt`;
          a.click();
          URL.revokeObjectURL(url);
        } else {
          Swal.fire({
            title: 'Coming soon',
            text: `Exporting to ${selectedFormat.toUpperCase()} is under development.`,
            icon: 'info',
            confirmButtonColor: '#18639c',
            customClass: { confirmButton: 'text-white px-5 py-2 rounded-md' },
          });
        }
      }
    });
  }

  // ==================================================
  // Limpiar el editor completamente (con confirmación)
  // ==================================================
  promptClearEditor() {
    Swal.fire({
      title: '<span class="text-[18px] font-bold">Clear Editor</span>',
      html: '<span class="text-[14px] text-gray-500">Are you sure you want to clear the editor?</span>',
      showCancelButton: true,
      confirmButtonColor: '#ff4d4f',
      cancelButtonColor: '#f3f4f6',
      confirmButtonText: 'Clear',
      cancelButtonText: '<span class="text-gray-700">Cancel</span>',
      width: '400px',
      customClass: {
        popup: 'rounded-xl shadow-lg border border-gray-100',
        confirmButton: 'px-5 py-2 rounded-md font-medium text-white',
        cancelButton: 'px-5 py-2 rounded-md font-medium text-gray-700',
      },
    }).then((result) => {
      if (result.isConfirmed) {
        // Vacía el editor y resetea contadores locales
        if (this.quillInstance) this.quillInstance.setText('');
        this.hasText.set(false);
        this.wordCount.set(0);
        this.charCount.set(0);

        // Guarda el contenido vacío en Firebase
        const note = this.notesService.selectedNote();
        if (note?.id) {
          this.notesService
            .updateNote(note.id, {
              titulo: note.titulo,
              contenido: '',
              pinned: note.pinned ?? false,
              archived: note.archived ?? false,
              deleted: false,
              fechaCreacion: note.fechaCreacion,
              fechaActualizacion: '',
            })
            .subscribe({
              next: (updated) => this.notesService.selectNote(updated),
            });
        }
      }
    });
  }
}
