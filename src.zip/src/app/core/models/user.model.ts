/**
 * Modelo del usuario autenticado en QuetzalNote.
 * Se popula tras un login exitoso con Google vía Firebase Identity Toolkit REST API.
 * Se persiste en localStorage para sobrevivir recargas de página.
 *
 * Responsable: Isidro (core/models/) — Blueprint §7
 */
export interface User {
  /** UID único del usuario en Firebase (localId). */
  uid: string;

  /** Correo electrónico de la cuenta de Google. */
  email: string;

  /** Nombre completo del usuario (displayName de Google). */
  displayName: string;

  /** URL de la foto de perfil de Google. */
  photoUrl: string;

  /**
   * Firebase ID Token (JWT).
   * Válido por 1 hora. Para uso futuro en endpoints que requieran auth.
   * NO almacenar en un lugar público ni enviarlo innecesariamente.
   */
  idToken: string;
}
